# MvcAffableBean
Asp.net MVC implementation of the Affable Bean project from Netbeans JAVA tutorial

This is an application original appeared for JAVA EE netbeans tutorial and can be found here: the https://netbeans.org/kb/docs/javaee/ecommerce/design.html

I have adapted the porject idea and implemented it in ASP.net MVC

This will work as a step by step tutorial for implementing a complete asp.net MVC project

An accompanying blog with screenshots can be read from here: https://shakeelosmani.wordpress.com/2015/12/27/asp-net-mvc-step-by-step-complete-e-commerce-tutorial/
